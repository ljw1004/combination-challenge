import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import * as E from './logical-retained-project.ts';
import {MATERIALS_RECIPES} from './retained-project-content.ts';
import type {Action,State,Part,CreateOptions} from './retained-project-types.ts';
const hash=(x:unknown)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const sha=(path:string)=>createHash('sha256').update(readFileSync(path)).digest('hex');
const flatten=(p:Part):Part[]=>[p,...p.children.flatMap(x=>flatten(x.part))];
const output=process.argv[2]??'results/retained-project-independent/campaign';
const freezePath=process.argv[3];if(!freezePath)throw Error('Require explicit stable freeze manifest path as second argument; do not run against changing sources.');
const freeze=JSON.parse(readFileSync(freezePath,'utf8'));const before=Object.fromEntries(freeze.files.map((f:any)=>{assert.equal(sha(f.path),f.sha256);return [f.path,f.sha256]}));
function control(options:CreateOptions,utilityDesign?:string){
 let state=E.createRetainedProject(options);const trace:any[]=[],actions:Action[]=[],milestones:any[]=[];
 const objects=()=>state.boards[0]!.objects;const object=(id:string)=>objects().find(o=>o.id===id||o.members?.some(m=>m.id===id))!;const initial=(key:string)=>objects().find(o=>o.initialKey===key||o.members?.some(m=>m.initialKey===key))!.id;
 function submit(a:string,b:string,context?:Action['context']){const action:Action={type:'combine',a,b,...context?{context}:{}};const before=state,oldGoals=E.retainedProjectGoals(before);const preview=E.previewRetainedProject(before,action);state=E.stepRetainedProject(before,action);assert.equal(state.accepted,true,`${actions.length+1}: ${JSON.stringify(action)} ${state.response}`);assert.deepEqual(state,preview.state);actions.push(action);const goals=E.retainedProjectGoals(state);trace.push({seq:actions.length-1,action,beforeHash:hash(before),afterHash:hash(state),response:state.response,goals:goals.map(g=>({id:g.id,current:g.current,achieved:g.achieved,satisfied:g.satisfied}))});for(const g of goals.filter(g=>g.achieved&&!oldGoals.find(x=>x.id===g.id)!.achieved))milestones.push({combine:actions.length,id:g.id});}
 function learn(name:string){if(state.known.includes(name))return;const recipe=MATERIALS_RECIPES.find(r=>r.result===name);assert(recipe,`Need explicit material transformation for ${name}`);learn(recipe.a);learn(recipe.b);submit(recipe.a,recipe.b);}
 function place(name:string,where:string){const previous=new Set(objects().map(o=>o.id));if(state.known.includes(name))submit(name,'place:'+where);else{const r=MATERIALS_RECIPES.find(r=>r.result===name);assert(r);learn(r.a);learn(r.b);submit(r.a,r.b,{at:where});}return objects().find(o=>!previous.has(o.id)&&o.place===where&&o.design===name)!.id;}
 function add(host:string,name:string,operation?:'inside'|'outside'){learn(name);submit(host,name,operation?{operation}:undefined);}
 const move=(id:string,p:string)=>submit(id,'place:'+p),op=(id:string,p:string,operation:'observe'|'transmit'|'sample'|'fit',part?:string)=>submit(id,'place:'+p,{operation,...part?{part}:{}}),pose=(id:string,operation:'fold'|'close'|'aim',direction?:'west'|'east')=>submit(id,id,{operation,...direction?{direction}:{}}),link=(a:string,b:string,channel:'power'|'water'|'light')=>submit(a,b,{operation:'connect',channel});
 const material=(id:string)=>flatten(object(id).root).find(p=>p.kind==='material')!.id;
 function transform(a:string,b:string,recipe:string,part?:string){const prior=new Set(objects().map(o=>o.id));submit(a,b,{operation:'transform',recipe,...part?{part}:{}});return objects().find(o=>o.id===a||!prior.has(o.id))!.id;}
 // A cheap, independently specified transport/record utility deliberately omits
 // the implementer's tube, heater, lamp and dual solar systems on every copy.
 if(!utilityDesign){const transport=place('cart','work-yard');add(transport,'hinge');add(transport,'camera');utilityDesign=object(transport).design;}
 const utilityBuild=actions.length;const equip=(id:string)=>add(id,utilityDesign!,'outside');
 const heat=place('solar-heater','survey-window');let survey=transform('sand',heat,'fuse');submit(survey,initial('survey-camera'),{operation:'inside'});op(survey,'beacon','observe');equip(survey);
 const nursery=place('clear-cast','garden');submit(nursery,initial('nursery'),{operation:'inside'});add(nursery,'lamp','outside');add(nursery,'camera','inside');
 const sunE=place('solar-lead','ridge'),sunW=place('solar-lead','ridge');pose(sunW,'aim','west');link(sunE,nursery,'power');link(sunW,nursery,'power');
 const clay=initial('working-clay');transform(clay,'place:filter-pad','wet-clay');add(clay,'tube');op(clay,'filter-pad','fit',material(clay));link(clay,nursery,'water');op(nursery,'lookout','observe');op(nursery,'receiver','transmit');
 const shade=place('clear-cast','shade-bed');transform(shade,'mesh','frost');add(shade,'rootbed','inside');const mirror=place('reflective-shell','mirror-perch');pose(mirror,'aim','west');link(mirror,shade,'light');
 // Replacement service uses geometry, not fabricated trial history. Complete
 // conditions later may reuse already-known geometry without retaking a trial.
 equip(clay);const kiln=place('solar-heater','filter-pad');transform(clay,kiln,'fire',material(clay));const geometry=object(clay).design;
 const filter=place(geometry,'filter-pad');op(filter,'filter-pad','fit',material(filter));link(filter,nursery,'water');
 const basin=place(geometry,'basin');transform(basin,'clear-film','line',material(basin));op(basin,'basin','fit',material(basin));
 transform(clay,'clear-film','line',material(clay));move(clay,'work-yard');move(survey,'press');submit(survey,clay,{operation:'transmit'});
 // Source-dependent reference copies are made before the survey goes away.
 const master=initial('mesh-master');const paper=transform('fiber','place:casting-bay','pulp');transform(paper,master,'sheet');equip(paper);move(paper,'press');transform(paper,survey,'impress',material(paper));move(paper,'paper-slot');op(paper,'paper-slot','fit',material(paper));
 const reference=place('record-sheet','press');transform(reference,survey,'impress');
 const display=place('record-sheet','press');transform(display,survey,'impress');transform(display,'clear-film','laminate');equip(display);move(display,'wet-gallery');

 add(master,'frame');add(master,'sample-tray','inside');equip(master);move(master,'table');op(master,'table','sample');move(master,'archive-bay');submit(survey,master,{operation:'transmit'});
 const relief=place('soft-clay','relief');transform(relief,'place:relief','take-form');const reliefHeat=place('solar-heater','relief');transform(relief,reliefHeat,'fire');transform(relief,'clear-film','line');equip(relief);move(relief,'wet-gallery');
 move(survey,'far-view');op(survey,'far-marker','observe');op(survey,'receiver','transmit');const dark=place('reflective-shell','far-view');submit(dark,survey,{operation:'inside'});survey=dark;pose(survey,'fold');move(survey,'dock');pose(survey,'close');pose(clay,'fold');move(clay,'collection');pose(clay,'close');
 const finalGoals=E.retainedProjectGoals(state);assert(finalGoals.every(g=>g.satisfied),JSON.stringify(finalGoals.filter(g=>!g.satisfied)));assert.equal(state.status,'complete');assert.deepEqual(E.replayRetainedProject(actions,options),state);
 return {evidence:'Independently authored source-informed goal-sensitive cheap transport/record prefab control; not a fresh play, optimum, or goal-insensitive proof. Prior authored route structure was read; no control function imported.',options,utilityDesign,utilityBuild,actions,trace,milestones,interventions:actions.length,ledger:state.ledger,finalGoals,state,previewExact:true,replayExact:true};
}
const ordinary=control({catalogue:'ordinary'}),complete=control({catalogue:'complete'}),saved=control({catalogue:'complete',known:ordinary.state.known,designs:ordinary.state.designs},ordinary.utilityDesign);mkdirSync(output,{recursive:true});for(const [name,data]of Object.entries({ordinary,complete,saved}))writeFileSync(`${output}/${name}.json.gz`,gzipSync(JSON.stringify({sourceHashes:before,...data}),{level:9}));
for(const [path,expected]of Object.entries(before))assert.equal(sha(path),expected,path);
const summary={sourceFreeze:freezePath,sourceHashes:before,evidence:ordinary.evidence,sourceUnchanged:true,results:Object.entries({ordinary,complete,saved}).map(([name,x])=>({name,interventions:x.interventions,utilityBuild:x.utilityBuild,ledger:x.ledger,status:x.state.status,finalGoals:x.finalGoals,milestones:x.milestones,previewExact:true,replayExact:true}))};writeFileSync(`${output}/summary.json`,JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({passed:true,results:summary.results.map(x=>({name:x.name,interventions:x.interventions,utilityBuild:x.utilityBuild}))},null,2));
